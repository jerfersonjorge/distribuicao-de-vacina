
#ifndef __MATRIZ_H_
#define __MATRIZ_H_

#define TAMANHO_MATRIZ 15

int* ler_arquivo(char *nome_arquivo, int quantidade_de_cidades);
void imprimir_matriz(int *matriz, int tamanho_matriz);
void liberar_matriz(int *matriz);

#endif // __MATRIZ_H_